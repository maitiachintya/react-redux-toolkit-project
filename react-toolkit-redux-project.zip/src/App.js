import './App.css';
import CounterView from './components/CounterView';

function App() {
  return (
    <div className="App">
      <CounterView />
    </div>
  );
}

export default App;
